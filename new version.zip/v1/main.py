import pygame
import os
import time
pygame.font.init()
pygame.mixer.init()

WIDTH, HEIGHT = 1550, 880
WIN = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)
pygame.display.set_caption("Cowboy Duel")
pygame.display.set_icon(pygame.image.load(os.path.join('Assets', 'blue_cowboy.png')))

BORDER = pygame.Rect(WIDTH//2 + 970, 0, 10, HEIGHT)

#BULLET_HIT_SOUND = pygame.mixer.Sound(os.path.join('Assets', 'Grenade+1.mp3'))
#BLUE_BULLET_FIRE_SOUND = pygame.mixer.Sound(os.path.join('Assets', 'ES_Gunshot Pistol 55 - SFX Producer.mp3'))
#RED_BULLET_FIRE_SOUND = pygame.mixer.Sound(os.path.join('Assets', 'ES_Gunshot Pistol 57 - SFX Producer.mp3'))
#DEATH_SOUND = pygame.mixer.Sound(os.path.join('Assets', 'ES_Scream Male Pain 2 - SFX Producer.mp3'))

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)
PURPLE = (128, 0, 128)
OPACITY = (255, 255, 255,0)

HEALTH_FONT = pygame.font.SysFont('ActionIsShaded', 40)
WINNER_FONT = pygame.font.SysFont('microsoftjhengheimicrosoftjhengheiuibold', 100)
FINISHER_FONT = pygame.font.SysFont('microsoftjhengheimicrosoftjhengheiuibold', 100)

gameDisplay = pygame.display.set_mode((WIDTH, HEIGHT))

FPS = 60
BLUE_VEL = 5.5
RED_VEL = 5.5
VEL = 4.6
BLUE_BULLET_VEL = 5.4
RED_BULLET_VEL = 5.4
RED_MAX = 6
BLUE_MAX = 6
clock = pygame.time.Clock()
countdown = 5
lastshot = pygame.time.get_ticks()



BLUE_GOT_HIT = pygame.USEREVENT + 1
RED_GOT_HIT = pygame.USEREVENT + 2


COWBOY_WIDTH, COWBOY_HEIGHT = 93, 93


BLUE_COWBOY_IMAGE = pygame.image.load(os.path.join('Assets', 'blue_cowboy.png'))
BLUE_COWBOY = pygame.transform.scale(BLUE_COWBOY_IMAGE, (COWBOY_WIDTH, COWBOY_HEIGHT))


RED_COWBOY_IMAGE = pygame.image.load(os.path.join('Assets', 'red_cowboy.png'))
RED_COWBOY = pygame.transform.scale(RED_COWBOY_IMAGE, (COWBOY_WIDTH, COWBOY_HEIGHT))

BACKGROUND = pygame.transform.scale(pygame.image.load(os.path.join('Assets', 'background.png')), (WIDTH, HEIGHT))


def draw_window(red, blue, red_bullets, blue_bullets, red_health, blue_health):
    WIN.blit(BACKGROUND, (0, 0))
    pygame.draw.rect(WIN, WHITE, BORDER)

    red_health_text = HEALTH_FONT.render("HEALTH: " + str(red_health), 1, RED)
    blue_health_text = HEALTH_FONT.render("HEALTH: " + str(blue_health), 1, BLUE)
    WIN.blit(red_health_text, (WIDTH - red_health_text.get_width() - 10, 10))
    WIN.blit(blue_health_text, (10, 10))

    WIN.blit(BLUE_COWBOY, (blue.x, blue.y))
    WIN.blit(RED_COWBOY, (red.x, red.y))

    for bullet in red_bullets:
        pygame.draw.rect(WIN, RED, bullet)

    for bullet in blue_bullets:
        pygame.draw.rect(WIN, BLUE, bullet)

    pygame.display.update()

def blue_movement(moving_left, moving_right, keys_pressed, blue):
    if keys_pressed[pygame.K_a] and blue.x - BLUE_VEL > - 45:
        blue.x -= BLUE_VEL
    if keys_pressed[pygame.K_d] and blue.x + BLUE_VEL + blue.width < BORDER.x + 15:  # RIGHT
        blue.x += BLUE_VEL
    if keys_pressed[pygame.K_w] and blue.y - BLUE_VEL > - 20:  # UP
        blue.y -= BLUE_VEL
    if keys_pressed[pygame.K_s] and blue.y + BLUE_VEL + blue.height < HEIGHT + 20:  # DOWN
        blue.y += BLUE_VEL



def red_movement(moving_left, moving_right, keys_pressed, red):
    if keys_pressed[pygame.K_LEFT] and red.x - RED_VEL > 0:  # LEFT
        red.x -= RED_VEL
    if keys_pressed[pygame.K_RIGHT] and red.x + RED_VEL + red.width < BORDER.x + 30:  # RIGHT
        red.x += RED_VEL
    if keys_pressed[pygame.K_UP] and red.y - RED_VEL > - 20: # UP
        red.y -= RED_VEL
    if keys_pressed[pygame.K_DOWN] and red.y + RED_VEL + red.height < HEIGHT + 20:  # DOWN
        red.y += RED_VEL


def handle_bullets(blue_bullets, red_bullets, blue, red):
    for bullet in blue_bullets:
        bullet.x += BLUE_BULLET_VEL
        if red.colliderect(bullet):
            pygame.event.post(pygame.event.Event(RED_GOT_HIT))
            blue_bullets.remove(bullet)
        elif bullet.x > WIDTH:
            blue_bullets.remove(bullet)

    for bullet in red_bullets:
        bullet.x -= RED_BULLET_VEL
        if blue.colliderect(bullet):
            pygame.event.post(pygame.event.Event(BLUE_GOT_HIT))
            red_bullets.remove(bullet)
        elif bullet.x < 0:
            red_bullets.remove(bullet)

font = pygame.font.SysFont(None, 25)

def text_objects(text, color):
    textSurface = font.render(text, True, color)
    return textSurface, textSurface.get_rect()

def message_to_screen(msg,color, y_displace=0, size= "small"):
    textSurf, textRect = text_objects(msg,color)
    textRect.center = (WIDTH / 2), (HEIGHT/2)+y_displace
    gameDisplay.blit(textSurf, textRect)


def draw(self):
    BLUE_COWBOY_IMAGE.blit(pygame.transform.flip(self.image, self.flip, False), BLUE_COWBOY_IMAGE.react)

def draw_bg():
	gameDisplay.blit(BACKGROUND, (0, 0))

def pause():
    paused = True
    while paused:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    paused = False

                elif event.key == pygame.K_q:
                    pygame.quit()
                    quit()


        gameDisplay.fill(WHITE, OPACITY)
        message_to_screen("Paused",
                          BLACK,
                          -100,
                          size= pygame.font.SysFont('microsoftjhengheimicrosoftjhengheiuibold', 70))

        message_to_screen("Press C to continue or Q to quit",
                          BLACK,
                          25,
                          )
        pygame.display.update()
        clock.tick(FPS)


def main():
    red = pygame.Rect(1200, 670, COWBOY_WIDTH, COWBOY_HEIGHT)
    blue = pygame.Rect(200, 670, COWBOY_WIDTH, COWBOY_HEIGHT)

    red_bullets = []
    blue_bullets = []

    red_health = 190
    blue_health = 190

    clock = pygame.time.Clock()
    run = True
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and len(blue_bullets) < BLUE_MAX:
                    bullet = pygame.Rect(blue.x + blue.width, blue.y + blue.height//2.4 - 2, 10, 5)
                    blue_bullets.append(bullet)
                    #BLUE_BULLET_FIRE_SOUND.play()

                if event.key == pygame.K_RCTRL and len(red_bullets) < RED_MAX:
                    bullet = pygame.Rect(red.x, red.y + red.height//2.4 - 2, 10, 5)
                    red_bullets.append(bullet)
                    #RED_BULLET_FIRE_SOUND.play()

                elif event.key == pygame.K_p:
                    pause()

            if event.type == RED_GOT_HIT:
                red_health -= 10
                #BULLET_HIT_SOUND.play()

            if event.type == BLUE_GOT_HIT:
                blue_health -= 10
                #BULLET_HIT_SOUND.play()


        winner_text = ""
        if red_health <= -1:
            #DEATH_SOUND.play()
            red_health = ""
            winner_text = "BLUE WIN!"
            def draw_winner(text):
                draw_text = WINNER_FONT.render(text, 1, BLUE)
                WIN.blit(draw_text, (WIDTH // 2 - draw_text.get_width() / 2, HEIGHT / 2 - draw_text.get_height() / 2))
                pygame.display.update()
                pygame.time.delay(2500)

        if blue_health <=-1:
            #DEATH_SOUND.play()
            winner_text = "RED WIN!"
            def draw_winner(text):
                draw_text = WINNER_FONT.render(text, 1, RED)
                WIN.blit(draw_text, (WIDTH // 2 - draw_text.get_width() / 2, HEIGHT / 2 - draw_text.get_height() / 2))
                pygame.display.update()
                pygame.time.delay(2500)

        if winner_text != "":
            draw_winner(winner_text)
            break

        keys_pressed = pygame.key.get_pressed()
        blue_movement(keys_pressed, blue, keys_pressed, blue)
        red_movement(keys_pressed, red, keys_pressed, red)

        handle_bullets(blue_bullets, red_bullets, blue, red)

        draw_window(red, blue, blue_bullets, red_bullets, red_health, blue_health)

    main()


if __name__ == "__main__":
    main()