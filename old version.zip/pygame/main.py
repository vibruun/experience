import pygame
import os
pygame.font.init()
#pygame.mixer.init()

WIDTH, HEIGHT = 900, 500
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Vegard Iversen Bruun Spill #1")
pygame.display.set_icon(pygame.image.load(os.path.join('Assets', 'blue_cowboy.png')))

BORDER = pygame.Rect(WIDTH//2 + 450, 0, 10, HEIGHT)

#BULLET_HIT_SOUND = pygame.mixer.Sound(os.path.join('Assets', 'Grenade+1.mp3'))
#BULLET_FIRE_SOUND = pygame.mixer.Sound(os.path.join('Assets', 'Gun+Silencer.mp3'))

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)
PURPLE = (128, 0, 128)

HEALTH_FONT = pygame.font.SysFont('ActionIsShaded', 40)
WINNER_FONT = pygame.font.SysFont('microsoftjhengheimicrosoftjhengheiuibold', 100)

FPS = 60
VEL = 4.6
BULLET_VEL = 100
RED_MAX = 10
BLUE_MAX = 10

BLUE_GOT_HIT = pygame.USEREVENT + 1
RED_GOT_HIT = pygame.USEREVENT + 2


COWBOY_WIDTH, COWBOY_HEIGHT = 130, 100

BLUE_COWBOY_IMAGE = pygame.image.load(
    os.path.join('Assets', 'blue_cowboy.png'))
BLUE_COWBOY = pygame.transform.scale(BLUE_COWBOY_IMAGE, (COWBOY_WIDTH, COWBOY_HEIGHT))


RED_COWBOY_IMAGE = pygame.image.load(
    os.path.join('Assets', 'red_cowboy.png'))
RED_COWBOY = pygame.transform.scale(RED_COWBOY_IMAGE, (COWBOY_WIDTH, COWBOY_HEIGHT))

SPACE = pygame.transform.scale(pygame.image.load(os.path.join('Assets', 'wild_west_background.jpg')), (WIDTH, HEIGHT))


def draw_window(red, blue, red_bullets, blue_bullets, red_health, blue_health):
    WIN.blit(SPACE, (0, 0))
    pygame.draw.rect(WIN, WHITE, BORDER)

    red_health_text = HEALTH_FONT.render("HEALTH: " + str(red_health), 1, RED)
    blue_health_text = HEALTH_FONT.render("HEALTH: " + str(blue_health), 1, BLUE)
    WIN.blit(red_health_text, (WIDTH - red_health_text.get_width() - 10, 10))
    WIN.blit(blue_health_text, (10, 10))

    WIN.blit(BLUE_COWBOY, (blue.x, blue.y))
    WIN.blit(RED_COWBOY, (red.x, red.y))

    for bullet in red_bullets:
        pygame.draw.rect(WIN, RED, bullet)

    for bullet in blue_bullets:
        pygame.draw.rect(WIN, BLUE, bullet)

    pygame.display.update()


def blue_movement(keys_pressed, blue):
    if keys_pressed[pygame.K_a] and blue.x - VEL > - 45:  # LEFT
        blue.x -= VEL
    if keys_pressed[pygame.K_d] and blue.x + VEL + blue.width < BORDER.x + 15:  # RIGHT
        blue.x += VEL
    if keys_pressed[pygame.K_w] and blue.y - VEL > - 20:  # UP
        blue.y -= VEL
    if keys_pressed[pygame.K_s] and blue.y + VEL + blue.height < HEIGHT + 20:  # DOWN
        blue.y += VEL


def red_movement(keys_pressed, red):
    if keys_pressed[pygame.K_LEFT] and red.x - VEL > 0:  # LEFT
        red.x -= VEL
    if keys_pressed[pygame.K_RIGHT] and red.x + VEL + red.width < BORDER.x + 30:  # RIGHT
        red.x += VEL
    if keys_pressed[pygame.K_UP] and red.y - VEL > - 20: # UP
        red.y -= VEL
    if keys_pressed[pygame.K_DOWN] and red.y + VEL + red.height < HEIGHT + 20:  # DOWN
        red.y += VEL



def handle_bullets(blue_bullets, red_bullets, blue, red):
    for bullet in blue_bullets:
        bullet.x += BULLET_VEL
        if red.colliderect(bullet):
            pygame.event.post(pygame.event.Event(RED_GOT_HIT))
            blue_bullets.remove(bullet)
        elif bullet.x > WIDTH:
            blue_bullets.remove(bullet)

    for bullet in red_bullets:
        bullet.x -= BULLET_VEL
        if blue.colliderect(bullet):
            pygame.event.post(pygame.event.Event(BLUE_GOT_HIT))
            red_bullets.remove(bullet)
        elif bullet.x < 0:
            red_bullets.remove(bullet)



def main():
    red = pygame.Rect(600, 300, COWBOY_WIDTH, COWBOY_HEIGHT)
    blue = pygame.Rect(100, 300, COWBOY_WIDTH, COWBOY_HEIGHT)

    red_bullets = []
    blue_bullets = []

    red_health = 200
    blue_health = 200

    clock = pygame.time.Clock()
    run = True
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and len(blue_bullets) < BLUE_MAX:
                    bullet = pygame.Rect(blue.x + blue.width, blue.y + blue.height//2.2 - 2, 7, 3)
                    blue_bullets.append(bullet)
                    #BULLET_FIRE_SOUND.play()

                if event.key == pygame.K_RCTRL and len(red_bullets) < RED_MAX:
                    bullet = pygame.Rect(red.x, red.y + red.height//2.2 - 2, 7, 3)
                    red_bullets.append(bullet)
                    #BULLET_FIRE_SOUND.play()

            if event.type == RED_GOT_HIT:
                red_health -= 10
                #BULLET_HIT_SOUND.play()

            if event.type == BLUE_GOT_HIT:
                blue_health -= 10
                #BULLET_HIT_SOUND.play()

        winner_text = ""
        if red_health <= 0:
            red_health == 0
            winner_text = "BLUE WIN!"
            def draw_winner(text):
                draw_text = WINNER_FONT.render(text, 1, BLUE)
                WIN.blit(draw_text, (WIDTH // 2 - draw_text.get_width() / 2, HEIGHT / 2 - draw_text.get_height() / 2))
                pygame.display.update()
                pygame.time.delay(2500)

        if blue_health <=-0:
            winner_text = "RED WIN!"
            def draw_winner(text):
                draw_text = WINNER_FONT.render(text, 1, RED)
                WIN.blit(draw_text, (WIDTH // 2 - draw_text.get_width() / 2, HEIGHT / 2 - draw_text.get_height() / 2))
                pygame.display.update()
                pygame.time.delay(2500)

        if winner_text != "":
            draw_winner(winner_text)
            break

        keys_pressed = pygame.key.get_pressed()
        blue_movement(keys_pressed, blue)
        red_movement(keys_pressed, red)

        handle_bullets(blue_bullets, red_bullets, blue, red)

        draw_window(red, blue, blue_bullets, red_bullets, red_health, blue_health)

    main()


if __name__ == "__main__":
    main()